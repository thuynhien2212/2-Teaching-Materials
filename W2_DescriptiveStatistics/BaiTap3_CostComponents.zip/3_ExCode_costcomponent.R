library(gtsummary)
library(plyr)
library(dplyr)
library(tidyr)
library(scales)
library(zoo)
library(lubridate)
library(stringr)
library(flextable)
library(ggplot2)
library(dplyr)
library(hrbrthemes)
library(NLP)
getwd()

setwd("D://OUCRU//OneDrive//Desktop//EHR 29.07.2025//2_Exercises")
data_costcomponent <- read.csv("3_Visualization_CostComponents.csv",encoding = "UTF-8")
colnames(data_costcomponent)
unique(data_costcomponent$Class) -> Class_Factor
data_costcomponent$Class <- factor(data_costcomponent$Class,levels=Class_Factor)
unique(data_costcomponent$Type) -> Type_Factor
data_costcomponent$Type <- factor(data_costcomponent$Type,levels=Type_Factor)
unique(data_costcomponent$Group) -> Group_Factor
data_costcomponent$Group <- factor(data_costcomponent$Group,levels=Group_Factor)
unique(data_costcomponent$Group) -> Group_Factor
data_costcomponent$Group <- factor(data_costcomponent$Group,levels=Group_Factor)
data_costcomponent_select <- data_costcomponent[!(data_costcomponent$Categories == "Total Hospital Cost"), ]
unique(data_costcomponent_select$Categories) -> Categories_Factor
data_costcomponent_select$Categories <- factor(data_costcomponent_select$Categories,levels=Categories_Factor)
unique(data_costcomponent_select$Name) -> Name_tag
data_costcomponent_select$Name <- factor(data_costcomponent_select$Name,levels=Name_tag)
library(ggrepel)
My_Theme_New = theme(
  axis.title.x = element_text(size = 12,face="bold"),
  axis.text.x = element_text(size = 12,face="bold"),
  axis.title.y = element_text(size = 12,face="bold"))
library(ggthemes)
library("viridis")
data_total <- subset(data_costcomponent,data_costcomponent$Categories == "Total Hospital Cost")
data_total$hjust_val <- ifelse(data_total$Name %in% c("All (n = 2,828)","3GCREC (n = 1,915)","3GCSEC (n = 913)","3GCSKP (n = 589)","All (n = 1,463)","MRSA (n = 1,064)","MSSA (n = 399)"), -0.7, 0.5)

chart_1 <- ggplot(data = data_costcomponent_select, aes(x=Name,y=Value,fill=Categories)) + 
  geom_bar(position="stack", stat="identity") + geom_text(aes(label = ifelse(Value>680,Value,"")),position = position_stack(vjust = .5)
                                                          , size = 2.5) + geom_text(data = data_total, 
                                                                                    aes(x = Name, y = Value, label = Value,hjust=hjust_val), 
                                                                                    vjust = 0.5, size = 3, fontface = "bold", 
                                                                                    inherit.aes = FALSE) + facet_wrap(Type ~.,scales = "free_y") + My_Theme_New + scale_fill_viridis(discrete = TRUE) + scale_x_discrete(labels=c("All (n = 613)" = "All \n (n = 613)", "CRAB (n = 468)" = "CRAB \n (n = 468)",
                                                                                                                                                                                                 "CSAB (n = 145)" = "CSAB \n (n = 145)","All (n = 730)"="All \n (n = 730)","CRPA (n = 303)"="CRPA \n (n = 303)", "CSPA (n = 427)"="CSPA \n (n = 427)","All (n = 2,828)"="All \n (n = 2,828)","3GCREC (n = 1,915)"="3GCREC \n (n = 1,915)","3GCSEC (n = 913)"="3GCSEC \n (n = 913)","All (n = 1,036)"="All \n (n = 1,036)",
                                                                                                                                                                                                 "3GCRKP (n = 447)"="3GCRKP \n (n = 447)","3GCSKP (n = 589)"="3GCSKP \n (n = 589)","All (n = 1,463)"="All \n (n = 1,463)", "MRSA (n = 1,064)"="MRSA \n (n = 1,064)","MSSA (n = 399)"="MSSA \n (n = 399)")) + 
  theme_bw() +theme(
    legend.position = c(0.81, 0.35),
    legend.key.height = unit(0.8, "cm"),      # Height of legend keys
    legend.key.width = unit(0.8, "cm"),       # Width of legend keys
    legend.spacing.y = unit(7, "cm"),       # Vertical spacing between items
    legend.spacing.x = unit(20, "cm"),       # Horizontal spacing between items
    legend.text = element_text(size = 10),     # Text size
    legend.title = element_text(size = 12,face="bold")    # Title size
  )  +
  guides(fill = guide_legend(title="Cost Components",nrow =5, byrow = TRUE)) + scale_y_continuous(breaks = seq(0, 18000, by = 3000)) + coord_flip()

chart_2 <- chart_1 + ylab("Median unadjusted hospital costs across five exposures ($, 2023)") + xlab("Exposure") +  theme(
  strip.text.x = element_text(
    size = 12, color = "black", face = "bold.italic"
  )) + theme(
    panel.background = element_rect(fill = "transparent", color = NA),   # panel area
    plot.background  = element_rect(fill = "transparent", color = NA),   # entire plot
    legend.background = element_rect(fill = "transparent", color = NA),
    legend.box.background = element_rect(fill = "transparent", color = NA)
  )

ggsave("test_2.tiff", plot = chart_2, 
       width = 14, height = 7, units = "in", dpi = 1000,
       bg = "transparent")


