library(gtsummary)
library(plyr)
library(dplyr)
library(tidyr)
library(scales)
library(zoo)
library(lubridate)
library(stringr)
library(flextable)
library(ggplot2)
library(dplyr)
library(hrbrthemes)
library(NLP)
getwd()
setwd("D://OUCRU//OneDrive//Desktop//EHR 29.07.2025//2_Exercises")
data_full <- read.csv("1_data_full_dacdiem_visinh.csv",encoding = "UTF-8")
summary(data_full)
#Set up dạng Date cho các biến ngày tháng năm
data_full$YearTest <- as.numeric(substr(data_full$SID,5,6)) + 2000
data_full$MonthTest <- as.numeric(substr(data_full$SID,3,4))
data_full$DayTest <- as.numeric(substr(data_full$SID,1,2))
data_full$DateIn <- as.Date(with(data_full, paste(YearIn, MonthIn, DayIn,sep="-")), "%Y-%m-%d")
data_full$DateOut <- as.Date(with(data_full, paste(YearOut, MonthOut, DayOut,sep="-")), "%Y-%m-%d")
data_full$DateTest <- as.Date(with(data_full, paste(YearTest, MonthTest, DayTest,sep="-")), "%Y-%m-%d")

#Set up các biến dạng factor
unique(data_full$GioiTinh)
data_full$GioiTinh <- factor(data_full$GioiTinh,levels= c("M","F"))
data_full$LocationHCM <- factor(data_full$LocationHCM,levels= c("Yes","No","Unknown"))
data_full$MucHuongBHYT_XetTuyen_New  <- ifelse(data_full$MucHuongBHYT_XetTuyen==0.6,data_full$MucHuongBHYT_XetTuyen*data_full$MucHuongBHYT_KhongXetTuyen,data_full$MucHuongBHYT_XetTuyen)
data_full$MucHuongBHYT_XetTuyen <- as.factor(data_full$MucHuongBHYT_XetTuyen)
data_full$MucHuongBHYT_KhongXetTuyen <- as.factor(data_full$MucHuongBHYT_KhongXetTuyen)
data_full$MucHuongBHYT_XetTuyen_New <- as.factor(data_full$MucHuongBHYT_XetTuyen_New)
data_full$Nhom.DoiTuongBHYT <- as.factor(data_full$Nhom.DoiTuongBHYT)
data_full$TypeOfInfection <- as.factor(data_full$TypeOfInfection)
data_full$ViTriLayMau <- as.factor(data_full$ViTriLayMau)
#Ex1: Set up dạng factor cho 2 biến TrangThaiNew (Reference:CaiThien) và Ward (Reference: Pediatrics)



#Tính toán các biến chưa có
data_full$Tuoi <- data_full$YearIn - data_full$NamSinh + 1
data_full$LOS <- as.numeric(data_full$DateOut - data_full$DateIn + 1)

#Phân nhóm cho biến: Chuyển đổi biến liên tục về biến phân loại (Tuoi, BMI, )
summary(data_full$Updated.Charlson.weight.score)
CCIClass <- c(0,0.99999,1.99999,2.9999,12)
data_full <- data_full %>% mutate(
  
  CCIGroup = cut(
    
    Updated.Charlson.weight.score,
    
    breaks = CCIClass,labels = c("0","1","2",">=3"),
    
    include.lowest = TRUE))

summary(data_full$TongSoBenh) 
NoDiseaseClass <- c(1,1.99999,2.9999,3.9999,4.9999,5.9999,48)
data_full <- data_full %>% mutate(
  
  NoDiseaseGroup = cut(
    
    TongSoBenh,
    
    breaks = NoDiseaseClass,labels = c("1 Disease","2 Diseases","3 Diseases","4 Diseases","5 Diseases",">=6 Diseases"),
    
    include.lowest = TRUE))

#Ex2: Phân nhóm biến cho biến Tuoi(<18; 18-49; 50-64;≥ 65) và BMI ((0; 18.5) - Underweight; [18.5;25) - Normal; [25;30) - Overweight; (30;100) - Obesity)









colnames(data_full)
data_full %>% select(NewCode,MergeCode,MaYTe,SoBenhAn,PID_o,SID,TenBenhNhan,GioiTinh,NamSinh,Tuoi,ChieuCao,CanNang,BMI,LocationHCM,Ward,ICDBenhChinh,ICDBenhChinh_ext,ICDBenhKem,TongSoBenh,ChanDoan,ChanDoanRa,FullDescription,GroupClassification,TypeOfInfection,Updated.Charlson.weight.score,ThanhToan,MucHuongBHYT_KhongXetTuyen,MucHuongBHYT_XetTuyen,MucHuongBHYT_XetTuyen_New,Nhom.DoiTuongBHYT,AgeGroup,BMIGroup,CCIGroup,NoDiseaseGroup,TrangThaiNew,ViTriLayMau,ICDBenhChinh_ext,FullDescription,TenViKhuan,ThoiGianCoKQ1,KetQuaCay,YearIn,MonthIn,DayIn,YearOut,MonthOut,DayOut,LOS) -> data_full_arrange

#Thống kê mô tả theo từng biến (khi mình cần visualize)
#Biến liên tục: Thống kê mô tả tuổi theo giới tính
Tuoi_By_GioiTinh <- data_full_arrange %>%
  group_by(GioiTinh) %>%
  summarise(
    Count = n(),
    Mean = mean(Tuoi, na.rm = TRUE),
    Median = median(Tuoi, na.rm = TRUE),
    SD = sd(Tuoi, na.rm = TRUE),
    Min = min(Tuoi, na.rm = TRUE),
    Max = max(Tuoi, na.rm = TRUE),
    Q1 = quantile(Tuoi, 0.25, na.rm = TRUE),
    Q3 = quantile(Tuoi, 0.75, na.rm = TRUE),
    IQR = IQR(Tuoi, na.rm = TRUE),
    Variance = var(Tuoi, na.rm = TRUE)
  )
#Hypothesis testing
# Tách 2 dataset M và F
group_M <- data_full_arrange$Tuoi[data_full_arrange$GioiTinh == "M"]
group_F <- data_full_arrange$Tuoi[data_full_arrange$GioiTinh == "F"]

# Kiểm tra phân phối chuẩn: Hàm shapiro.test() kiểm tra giả thuyết H0: “Dữ liệu phân phối chuẩn”; Nếu p-value < 0.05, ta bác bỏ H0 → Dữ liệu không phân phối chuẩn
norm1 <- shapiro.test(group_M)$p.value > 0.05
norm2 <- shapiro.test(group_F)$p.value > 0.05

# Kiểm tra phương sai bằng nhau-->FALSE: Phương sai giữa hai nhóm KHÔNG BẰNG NHAU
equal_var <- var.test(group_M, group_F)$p.value > 0.05

# Chọn phép kiểm định phù hợp
if (norm1 & norm2 & equal_var) {
  test_result <- t.test(Tuoi ~ GioiTinh, data = data_full_arrange, var.equal = TRUE)
} else {
  test_result <- wilcox.test(Tuoi ~ GioiTinh, data = data_full_arrange)
}
test_result

#Biến phân loại: Thống kê mô tả nhóm tuổi theo giới tính
NhomTuoi_By_GioiTinh <- data_full_arrange %>%
  group_by(GioiTinh, AgeGroup) %>%
  summarise(count = n(), .groups = "drop") %>%
  group_by(GioiTinh) %>%
  mutate(percent = round(100 * count / sum(count), 1))
#Hypothesis testing
library(textshape)
table_chisq <- NhomTuoi_By_GioiTinh %>%
  select(GioiTinh, AgeGroup, count) %>%
  pivot_wider(names_from = GioiTinh, values_from = count, values_fill = 0) %>%
  column_to_rownames("AgeGroup") %>%
  as.matrix()
chisq.test(table_chisq, simulate.p.value = TRUE)

#Ex3: Thống kê mô tả BMI và BMI group theo Khoa phòng



#Thống kê mô tả nhiều biến cùng 1 lúc
#Không phân nhóm
library(gtsummary)
data_full_arrange %>% select(TenViKhuan,GioiTinh,Tuoi,LocationHCM,Ward,BMIGroup,TongSoBenh,Updated.Charlson.weight.score,CCIGroup,TrangThaiNew,YearIn,LOS,MucHuongBHYT_KhongXetTuyen,MucHuongBHYT_XetTuyen,Nhom.DoiTuongBHYT) -> data_full_select_0
data_full_select_0 %>%
  tbl_summary(
    digits = list(all_categorical() ~ c(0, 2))
  ) %>%
  modify_header(label ~ "**Variable**") %>%
  modify_footnote(all_stat_cols() ~ "Median (IQR) or Frequency (%)") %>%
  modify_caption("**Table 1. Patient Characteristics**") %>%
  bold_labels() -> ViKhuan_tab_nolevel
tf <- tempfile(tmpdir = "D://OUCRU//OneDrive//Desktop//EHR 29.07.2025//2_Exercises",fileext = "character_ViKhuan_nolevel.docx")
ViKhuan_tab_nolevel %>% as_flex_table() -> ViKhuan_tab_flex_0
flextable::save_as_docx(ViKhuan_tab_flex_0,path = tf)


#Phân thành 2 nhóm (Level bậc 1)
data_full_arrange %>% select(TenViKhuan,GioiTinh,Tuoi,LocationHCM,Ward,BMIGroup,TongSoBenh,Updated.Charlson.weight.score,CCIGroup,TrangThaiNew,YearIn,LOS,MucHuongBHYT_KhongXetTuyen,MucHuongBHYT_XetTuyen,Nhom.DoiTuongBHYT) -> data_full_select_1
data_full_select_1 %>%
  tbl_summary(
    by = TenViKhuan,  # Compare by gender
    digits = list(all_categorical() ~ c(0, 2))
  ) %>%
  add_p(pvalue_fun = ~ style_pvalue(.x, digits = 2)) %>%
  add_overall() %>%
  modify_header(label ~ "**Variable**") %>%
  modify_footnote(all_stat_cols() ~ "Median (IQR) or Frequency (%)") %>%
  modify_caption("**Table 1. Patient Characteristics by Gender**") %>%
  bold_labels() -> ViKhuan_tab_onelevel
tf <- tempfile(tmpdir = "D://OUCRU//OneDrive//Desktop//EHR 29.07.2025//2_Exercises",fileext = "character_ViKhuan_onelevel.docx")
ViKhuan_tab_onelevel %>% as_flex_table() -> ViKhuan_tab_flex_1
flextable::save_as_docx(ViKhuan_tab_flex_1,path = tf)


#Phân thành 2 levels
data_full_arrange %>% select(TenViKhuan,MergeCode,GioiTinh,Tuoi,LocationHCM,Ward,BMIGroup,TongSoBenh,Updated.Charlson.weight.score,CCIGroup,TrangThaiNew,YearIn,LOS,MucHuongBHYT_KhongXetTuyen,MucHuongBHYT_XetTuyen,Nhom.DoiTuongBHYT) -> data_full_select_2
data_full_select_2 %>%
tbl_strata(
  strata = TenViKhuan,
  ~.x %>% tbl_summary(by = MergeCode,digits = list(all_categorical() ~ c(0, 2))) %>%
    add_p(pvalue_fun = ~ style_pvalue(.x, digits = 2)) %>%
    add_overall() %>%
    modify_header(label ~ "**Variable**") %>%
    modify_spanning_header(c("stat_1", "stat_2") ~ "**Type of Resistance**") %>%
    modify_footnote(
      all_stat_cols() ~ "Median (IQR) or Frequency (%)"
    ) %>%
    modify_caption("**Table 1. Patient Characteristics**") %>%
    bold_labels()
) -> ViKhuan_tab_twolevels
tf <- tempfile(tmpdir = "D://OUCRU//OneDrive//Desktop//EHR 29.07.2025//2_Exercises",fileext = "character_ViKhuan_twolevels.docx")
ViKhuan_tab_twolevels %>% as_flex_table() -> ViKhuan_tab_flex_2
flextable::save_as_docx(ViKhuan_tab_flex_2,path = tf)

#Ex4:Thống kê các đặc điểm nhân khẩu học ở người bệnh
#Theo giới tính
#Theo giới tính và nhóm tuổi