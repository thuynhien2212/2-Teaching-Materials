library(gtsummary)
library(plyr)
library(dplyr)
library(tidyr)
library(scales)
library(zoo)
library(lubridate)
library(stringr)
library(flextable)
library(ggplot2)
library(dplyr)
library(hrbrthemes)
library(NLP)
getwd()
setwd("D://OUCRU//OneDrive//Desktop//EHR 29.07.2025//2_Exercises")
data_chiphi_full <- read.csv("2_data_full_chiphi.csv",encoding = "UTF-8")
data_chiphi_full$GioiTinh <- factor(data_chiphi_full$GioiTinh,levels= c("M","F"))
data_chiphi_full$LocationHCM <- factor(data_chiphi_full$LocationHCM,levels= c("Yes","No","Unknown"))
data_chiphi_full$MucHuongBHYT_XetTuyen_New  <- ifelse(data_chiphi_full$MucHuongBHYT_XetTuyen==0.6,data_chiphi_full$MucHuongBHYT_XetTuyen*data_chiphi_full$MucHuongBHYT_KhongXetTuyen,data_chiphi_full$MucHuongBHYT_XetTuyen)
data_chiphi_full$MucHuongBHYT_XetTuyen <- as.factor(data_chiphi_full$MucHuongBHYT_XetTuyen)
data_chiphi_full$MucHuongBHYT_KhongXetTuyen <- as.factor(data_chiphi_full$MucHuongBHYT_KhongXetTuyen)
data_chiphi_full$MucHuongBHYT_XetTuyen_New <- as.factor(data_chiphi_full$MucHuongBHYT_XetTuyen_New)
data_chiphi_full$Nhom.DoiTuongBHYT <- as.factor(data_chiphi_full$Nhom.DoiTuongBHYT)
data_chiphi_full %>% select(TenViKhuan,MergeCode,starts_with("VND2023"),starts_with("USD2023")) -> data_chiphi_select
data_chiphi_select %>%
  tbl_strata(
    strata = TenViKhuan,
    ~.x %>% tbl_summary(by = MergeCode, type = list(c("VND2023_kham","USD2023_kham") ~ "continuous"),statistic = list(
      all_continuous() ~  "{median} ({p25}, {p75})"),
      digits = all_continuous() ~ 0) %>%
      add_p(pvalue_fun = ~ style_pvalue(.x, digits = 2)) %>%
      add_overall() %>%
      modify_header(label ~ "**Variable**") %>%
      modify_spanning_header(c("stat_1", "stat_2") ~ "**Type of Resistance**") %>%
      modify_footnote(
        all_stat_cols() ~ "Median (IQR)"
      ) %>%
      modify_caption("**Table 2. Cost Data**") %>%
      bold_labels()
  ) -> ChiPhi_tab
tf <- tempfile(tmpdir = "D://OUCRU//OneDrive//Desktop//EHR 29.07.2025//2_Exercises",fileext = "chiphi_ViKhuan.docx")
ChiPhi_tab %>% as_flex_table() -> ChiPhi_tab_flex
flextable::save_as_docx(ChiPhi_tab_flex,path = tf)

#So sánh tổng chi phí giữa 2 nhóm Nam và Nữ
ggplot(data_chiphi_full, aes(x = GioiTinh, y = USD2023_TongVienPhi, fill = GioiTinh)) +
  geom_bar(stat = "identity", width = 0.6) +
  labs(title = "Comparison of Cost Between Male and Female",
       x = "Gender",
       y = "Cost (USD)") +
  theme_minimal() +
  theme(legend.position = "bottom")

# Ex5: So sánh tổng chi phí giữa các khoa phòng

# Ex6: Vẽ biểu đồ tương quan giữa tuổi và chi phí